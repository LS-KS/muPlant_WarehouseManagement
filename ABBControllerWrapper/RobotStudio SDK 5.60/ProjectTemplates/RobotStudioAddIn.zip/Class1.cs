using System;
using System.Collections.Generic;
using System.Text;

using ABB.Robotics.Math;
using ABB.Robotics.RobotStudio;
using ABB.Robotics.RobotStudio.Environment;
using ABB.Robotics.RobotStudio.Stations;

//	To activate this Add-In you have to install it in the RobotStudio Add-In directory,
//  typically C:\Program Files\Common Files\ABB Industrial IT\Robotics IT\RobotStudio\AddIns
//  There are two alternatives: copy $safeprojectname$.dll to the Add-In directory, or
//  copy $safeprojectname$.rsaddin to the Add-In directory.
// 
//  The rsaddin file provides additional information to the RobotStudio host before the
//  Add-In assembly has been loaded, as specified in RobotStudioAddin.xsd. It also
//  allows more flexibility in locating the Add-In assembly, which can be useful
//	during development. 
namespace $safeprojectname$
{
	public class Class1
	{
		// This is the entry point for the Add-In
		public static void AddinMain()
		{

		}
	}
}